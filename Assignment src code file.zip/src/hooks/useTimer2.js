import { useState, useRef, useEffect } from 'react';

const useTimer = (initialState = 0) => {
    const [timer, setTimer] = useState(initialState)
    const [isActive, setIsActive] = useState(true)
    const [isPaused, setIsPaused] = useState(true)
    const countRef = useRef(null)


    useEffect(() => {
        countRef.current = setInterval(() => {
            setTimer((timer) => timer + 1)
        }, 1000)
        return(()=>{
            clearInterval(countRef.current)
        })
    }, [isActive])

    const handlePause = () => {
        clearInterval(countRef.current)
        setIsPaused(false)
    }

    const handleResume = () => {
        setIsPaused(true)
        countRef.current = setInterval(() => {
            setTimer((timer) => timer + 1)
        }, 1000)
    }

    const handleReset = () => {
        clearInterval(countRef.current)
        setIsActive(false)
        setIsActive(true)
        setIsPaused(true)
        setTimer(0)
    }

    return { timer, isActive, isPaused, handlePause, handleResume, handleReset }
}

export default useTimer
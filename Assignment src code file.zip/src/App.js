
import './App.css';
import SecondAssignment from './components/SecondAssignment';
import Timer from './components/Timer';

const App = () => {
  return (
    <div className="app">
      <Timer />
      <div style={{"position":"relative", "top": "50%"}}>
        <SecondAssignment />
      </div>
    </div>
  );
}

export default App;